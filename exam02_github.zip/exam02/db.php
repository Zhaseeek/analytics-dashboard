<?php

$con = mysqli_connect(
    "YOUR_DATABASE_HOST",
    "YOUR_DATABASE_USER",
    "YOUR_DATABASE_PASSWORD",
    "YOUR_DATABASE_NAME"
);

if (!$con) {
    die("Failed to connect to MySQL: " . mysqli_connect_error());
}

?>
