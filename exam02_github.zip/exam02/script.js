async function loadExpenses(api, div, title) {
  const data = await fetch(api).then(r => r.json());

  Plotly.newPlot(div, [{
    x: data.map(i => i.month),
    y: data.map(i => i.amount),
    type: 'bar',
    text: data.map(i => i.amount),
    textposition: 'outside',
    marker: {
      color: '#f2c6d6',
      line: { color: '#e8aebe', width: 1 }
    }
  }], {
    title: {
      text: title,
      font: { size: 18, color: '#444', family: 'Arial' }
    },
    margin: { t: 50 },
    bargap: 0.35,
    paper_bgcolor: '#ffffff',
    plot_bgcolor: '#ffffff',
    xaxis: { tickfont: { color: '#666' }, showline: false },
    yaxis: {
      gridcolor: '#f3e8ee',
      zeroline: false,
      tickfont: { color: '#666' }
    }
  });
}

async function loadVisitors(api, div, title) {
  const data = await fetch(api).then(r => r.json());

  Plotly.newPlot(div, [{
    x: data.map(i => i.day),
    y: data.map(i => i.visitors),
    type: 'bar',
    text: data.map(i => i.visitors),
    textposition: 'outside',
    marker: { color: '#0ea5e9' }
  }], {
    title: title,
    margin: { t: 40 },
    yaxis: { rangemode: 'tozero' }
  });
}

async function loadEmployees(api, div, title) {
  const data = await fetch(api).then(r => r.json());

  Plotly.newPlot(div, [{
    labels: data.map(i => i.department),
    values: data.map(i => i.count),
    type: 'pie',
    hole: 0.55,
    textinfo: 'label+percent',
    textfont: { size: 13, color: '#444' },
    marker: {
      colors: ['#E63946', '#457B9D', '#2A9D8F', '#F4A261', '#9B5DE5', '#43AA8B'],
      line: { color: '#ffffff', width: 2 }
    }
  }], {
    title: {
      text: title,
      font: { size: 18, color: '#333' }
    },
    margin: { t: 60 },
    paper_bgcolor: '#ffffff',
    plot_bgcolor: '#ffffff',
    showlegend: true,
    legend: {
      orientation: 'v',
      font: { size: 13, color: '#444' }
    }
  });
}

async function loadActivity(api, div, title) {
  const data = await fetch(api).then(r => r.json());

  Plotly.newPlot(div, [{
    labels: data.map(i => i.source),
    values: data.map(i => i.value),
    type: 'pie',
    hole: 0.6,
    textinfo: 'percent',
    textfont: { size: 13, color: '#555' },
    marker: {
      colors: ['#e8d8c4', '#c7b7a3', '#d6cfc4', '#b7c4b1', '#c1c8d6', '#e3cfcf'],
      line: { color: '#ffffff', width: 2 }
    }
  }], {
    title: {
      text: title,
      font: { size: 18, color: '#444', family: 'Arial' }
    },
    margin: { t: 60 },
    paper_bgcolor: '#ffffff',
    plot_bgcolor: '#ffffff',
    showlegend: true,
    legend: {
      orientation: 'v',
      font: { size: 13, color: '#666' }
    }
  });
}

async function testApi(url, outputId) {
  const out = document.getElementById(outputId);
  out.classList.remove("d-none");
  out.textContent = "Testing...";

  try {
    const res = await fetch(url);
    const json = await res.json();

    out.textContent =
      "STATUS: " + res.status + "\n\n" +
      JSON.stringify(json, null, 2);
  } catch (e) {
    out.textContent = "ERROR: " + e;
  }
}

loadExpenses('monthlyAPI.php', 'expensesChart', 'Monthly Expenses');
loadVisitors('websiteAPI.php', 'visitorsChart', 'Website Visitors');
loadEmployees('employeesAPI.php', 'employeesChart', 'Employees Distribution');
loadActivity('activityAPI.php', 'activityChart', 'Activity Sources');
