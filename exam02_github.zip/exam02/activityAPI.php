<?php

header("Content-Type: application/json");
include('db.php');

$result = mysqli_query($con, "SELECT source, value FROM `activity_sources`");
$data = [];

while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    $data[] = $row;
}

echo json_encode($data);
mysqli_close($con);

?>
