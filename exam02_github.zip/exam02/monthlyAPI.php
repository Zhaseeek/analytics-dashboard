<?php

header("Content-Type: application/json");
include('db.php');

$result = mysqli_query($con, "SELECT month, amount FROM `monthly_expenses`");
$data = [];

while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    $data[] = $row;
}

echo json_encode($data);
mysqli_close($con);

?>
