<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Analytics Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.plot.ly/plotly-latest.min.js"></script>
  <style>
    body { background: #f5f7fb; }
    .card { border-radius: 14px; box-shadow: 0 6px 18px rgba(0, 0, 0, 0.05); }
    .chart { height: 320px; }
    pre { max-height: 200px; overflow: auto; }
  </style>
</head>
<body>
<div class="container py-4">
  <h3 class="text-center mb-4">Analytics</h3>
  <div class="row g-4">

    <div class="col-md-6">
      <div class="card p-3">
        <h6>Monthly Expenses</h6>
        <div id="expensesChart" class="chart"></div>
        <a href="monthlyAPI.php" class="btn btn-sm btn-outline-primary" target="_blank">Show API</a>
        <button class="btn btn-sm btn-outline-success mt-2"
                onclick="testApi('monthlyAPI.php','expensesTest')">
          Show test
        </button>
        <pre id="expensesTest" class="mt-2 bg-light p-2 small d-none"></pre>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card p-3">
        <h6>Website Visitors</h6>
        <div id="visitorsChart" class="chart"></div>
        <a href="websiteAPI.php" class="btn btn-sm btn-outline-primary" target="_blank">Show API</a>
        <button class="btn btn-sm btn-outline-success mt-2"
                onclick="testApi('websiteAPI.php','visitorsTest')">
          Show test
        </button>
        <pre id="visitorsTest" class="mt-2 bg-light p-2 small d-none"></pre>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card p-3">
        <h6>Employee Distribution</h6>
        <div id="employeesChart" class="chart"></div>
        <a href="employeesAPI.php" class="btn btn-sm btn-outline-primary" target="_blank">Show API</a>
        <button class="btn btn-sm btn-outline-success mt-2"
                onclick="testApi('employeesAPI.php','employeesTest')">
          Show test
        </button>
        <pre id="employeesTest" class="mt-2 bg-light p-2 small d-none"></pre>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card p-3">
        <h6>Activity Sources</h6>
        <div id="activityChart" class="chart"></div>
        <a href="activityAPI.php" class="btn btn-sm btn-outline-primary" target="_blank">Show API</a>
        <button class="btn btn-sm btn-outline-success mt-2"
                onclick="testApi('activityAPI.php','activityTest')">
          Show test
        </button>
        <pre id="activityTest" class="mt-2 bg-light p-2 small d-none"></pre>
      </div>
    </div>

  </div>
</div>

<script src="script.js"></script>
</body>
</html>
